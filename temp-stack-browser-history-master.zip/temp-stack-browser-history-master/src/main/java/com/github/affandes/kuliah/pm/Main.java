package com.github.affandes.kuliah.pm;

public class Main {
    public static void main(String[] args) {
        // Tulis kode disini

    }
}