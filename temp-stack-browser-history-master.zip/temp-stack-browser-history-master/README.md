# Stack - Browser History

Buat sebuah program yang mensimulasikan prinsip kerja history browser. Program ini memiliki 3 fungsi utama, yaitu `view`, `browse` dan `back`.

Fungsi `view` digunakan untuk menampilkan semua history browser yang diurutkan dari yang paling baru.

Fungsi `browse` digunakan untuk menambahkan website baru ke dalam daftar history.

Fungsi `back` digunakan untuk kembali ke website sebelumnya dan menghapus history terakhir.

Anda dapat memodifikasi kode sesuai dengan kebutuhan.

## Credit

Tugas ini dibuat oleh Muhammad Affandes <[affandes@uin-suska.ac.id](mailto:affandes@uin-suska.ac.id)>